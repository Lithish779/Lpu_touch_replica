package com.example.lpu_touch

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
